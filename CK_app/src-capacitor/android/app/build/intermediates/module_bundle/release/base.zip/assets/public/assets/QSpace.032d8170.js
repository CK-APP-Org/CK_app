import{h as e,k as a}from"./index.3a795f78.js";const p=e("div",{class:"q-space"});var c=a({name:"QSpace",setup(){return()=>p}});export{c as Q};
